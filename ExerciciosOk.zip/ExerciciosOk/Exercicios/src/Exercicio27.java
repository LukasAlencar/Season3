
import java.util.Scanner;

public class Exercicio27 {
	Scanner scan = new Scanner(System.in);
	public void run01(){

		
		int i = 0;
		double soma = 0;
		double num = 1;
		do{
			
			System.out.println("Digite uma nota: ");
			num = scan.nextDouble();
			if(num >= 0) {
			soma = soma + num;
			}
			i++;
		}while(num >= 0);
		double media = soma / (i - 1);
		System.out.println(i);
		System.out.println(soma);
		System.out.println("a media �: " + media);
		
	}
	
}