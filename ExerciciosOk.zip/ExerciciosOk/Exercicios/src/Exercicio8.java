import java.util.Scanner;

/*Leia tr�s n�meros inteiros fornecidos pelo usu�rio. Descubra qual deles � o maior de todos, imprimindo seu valor. */

public class Exercicio8 {

	Scanner input = new Scanner(System.in);
	public void run01() {
		
		int valor[] = new int[3];
		
		System.out.println("Informe um valor (A): ");
		valor[0]= input.nextInt();
		
		System.out.println("Informe um valor (B): ");
		valor[1]= input.nextInt();
		
		System.out.println("Informe um valor (C): ");
		valor[2]= input.nextInt();
		
		int aux = valor[0];
		
		for(int i = 0; i < valor.length; i++) {
			if(valor[i] > aux) {
				aux = valor[i]; 
			}
		}
		
		System.out.println("O maior valor digitado foi: "+ aux);
		
	}
}
