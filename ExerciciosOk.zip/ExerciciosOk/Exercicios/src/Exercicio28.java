
public class Exercicio28 {
	
	
	public void run01() {
		
		boolean a = true;
		boolean b = false;
		boolean c = true;

		System.out.println("|A| |B| |C|\n"
					     + "|V| |V| |V| = |V|\n"
					     + "|V| |F| |F| = |F|\n"
					     + "|V| |V| |F| = |F|\n"
					     + "|V| |F| |V| = |F|\n"
					     + "|F| |V| |V| = |F|\n"
					     + "|F| |F| |V| = |F|\n"
					     + "|F| |F| |F| = |F|\n");
		
		
		verificarVF1(a, b, c);
	}
	
	public void verificarVF1(boolean a, boolean b, boolean c) {
		
		if(a == true && b == true && c == true) {
			System.out.println("\nVariavel A declarada como: " + a + "\nVariavel B declarada como: " + b 
					+ "\nVariavel C declarada como: " + c + "\nentao a declaracao eh: Verdadeira");
			
		}else {
			System.out.println("\nVariavel A declarada como: " + a + "\nVariavel B declarada como: " + b 
					+ "\nVariavel C declarada como: " + c + "\nentao a declaracao eh: Falsa");
		}
		
	}
	
	
}
