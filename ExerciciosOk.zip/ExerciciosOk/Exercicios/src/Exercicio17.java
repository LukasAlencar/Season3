/*Escreva um programa que leia um valor inteiro correspondente a uma quantidade de segundos, convertendo o valor dado
em horas corridas sabendo que 3600 segundos equivalem a 1 hora, exibindo os valores dado e convertido. Caso o
usu�rio forne�a um valor negativo, deve ser exibida uma mensagem e a opera��o de convers�o n�o deve ser efetuada.*/


public class Exercicio17 {

	
	
}
