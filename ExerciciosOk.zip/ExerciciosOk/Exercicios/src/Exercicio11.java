import java.util.Scanner;

/*Escreva um programa que leia dois n�meros inteiros A e B quaisquer indicando se A � m�ltiplo de B ou se B � m�ltiplo
de A.*/

public class Exercicio11 {

	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe um valor (A): ");
		int valorA= input.nextInt();
		System.out.println("Informe um valor (B): ");
		int valorB= input.nextInt();
		
		if(valorA % valorB == 0) {
			System.out.println("A � multiplo de B");
		}else if(valorB % valorA == 0) {
			System.out.println("B � multiplo de A");
		}
	}
} 
