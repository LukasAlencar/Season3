/*Implementar tr�s programas para exibir a tabuada de um n�mero inteiro entre 1 e 20 dado pelo usu�rio.
a) Usando enquanto (while)
b) Usando fa�a-enquanto (do-while)
c) Usando para (for)*/


import java.util.Scanner;
public class Exercicio24 {
Scanner scan = new Scanner(System.in);
	
	
	
	
	public void run01() {
	
		
		System.out.println("Selecione uma opcao \n[1]While \n[2]do-While \n[3]for");
		int opc = scan.nextInt();
		
		switch(opc) {
		
			case 1:
				tWhile(); 	
			break;
			
			case 2:
				tDoWhile();
			break;
			
			case 3:
				tFor(); 
			break;
		}

	}
	
	public void tWhile() {
		System.out.println("Digite um numero inteiro de 1 a 20: ");
		int num = scan.nextInt();
		
		if(num < 1 || num > 20) {
			System.out.println("O numero nao corresponde ao solicitado\n");
			System.exit(0);
		}
			int i = 0;
			int aux = 0;
			while(i <= 10){
				aux = num * i;
				System.out.println(num + " x " + i + " = " + aux + "\n");
				i++;
			}
		
	
	}
	
	public void tDoWhile() {
		
		System.out.println("Digite um numero inteiro de 1 a 20: ");
		int num = scan.nextInt();
		
		
		if(num < 1 || num > 20) {
			System.out.println("O numero nao corresponde ao solicitado\n");
			System.exit(0);
		}
			int i = 0;
			int aux = 0;
			do {
				aux = num * i;
				System.out.println(num + " x " + i + " = " + aux + "\n");
				i++;
			}while(i <= 10);	
		
	}
	
	public void tFor() {
		System.out.println("Digite um numero inteiro de 1 a 20: ");
		int num = scan.nextInt();
		
		
		if(num < 1 || num > 20) {
			System.out.println("O numero nao corresponde ao solicitado\n");
			System.exit(0);
		}
			int i = 0;
			int aux = 0;
			for(i = 0; i <= 10; i++) {
				aux = num * i;
				System.out.println(num + " x " + i + " = " + aux + "\n");
			}
		
		
	}
}
