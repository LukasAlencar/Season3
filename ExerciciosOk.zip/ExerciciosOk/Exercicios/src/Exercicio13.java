import java.util.Scanner;

/*Dados 3 valores reais representando os lados de um poss�vel tri�ngulo, 
 * verifique se os mesmos formam um tri�ngulo (a medida de qualquer um de seus lados deve ser menor que 
 * a soma das medidas dos lados restantes). Caso seja formado um tri�ngulo, descubra tamb�m se este tri�ngulo
 *  � escaleno (tr�s lados diferentes),is�sceles (dois lados iguais) ou eq�il�tero (tr�s lados iguais).*/ 

public class Exercicio13 {
	Scanner input = new Scanner(System.in);
	
	
	public void run01() {
	
		
		System.out.println("Monte um triangulo");
		
		System.out.println("Informe o valor do lado (A): ");
		float a = input.nextFloat();
	
		System.out.println("Informe o valor do lado (B): ");
		float b = input.nextFloat();
	
		System.out.println("Informe o valor do lado (C): ");
		float c = input.nextFloat();
		
		System.out.println("Ele "+ ((c <= (a + b) && (a <= (b + c) && (b <= (a + c))))? "eh " : "n�o eh ")+ "um triangulo");
		
		if((c > (a + b) || (a > (b + c) || (b > (a + c))))) {
			System.exit(0);
		}else {
			if(a == b && b == c) {
				System.out.println("\nSe trata de um triangulo equilatero");
			}else if((a == b && b != c) || (a == c && c != b) || (b == c && c != a)) {
				System.out.println("\nSe trata de um triangulo isoceles");
			}else if(a != b && a != c) {
				System.out.println("\nSe trata de um triangulo escaleno");
			}
			
		}
		
		
		
	} 
	
}
