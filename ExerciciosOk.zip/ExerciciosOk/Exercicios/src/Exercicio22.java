import java.util.Scanner;

/*Considerando um objeto m�vel em movimento uniformemente variado, 
 * escreva um programa que receba as seguintes informa��es: um valor real indicando posi��o inicial do m�vel P0, 
um valor real que corresponde a velocidade do m�vel V, um outro valor real A correspondente a 
acelera��o do m�vel e um n�mero inteiro correspondente ao tempo decorrido T. O programa deve calcular a 
posi��o final PF do m�vel, dado pela rela��o abaixo: PF = P0 + V * T + (A * T2) / 2*/

public class Exercicio22 {

	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Indique a posicao inicial: ");
		float p0= input.nextFloat();
		System.out.println("Indique a velocidade: ");
		float v= input.nextFloat();
		System.out.println("Indique a aceleracao: ");
		float a= input.nextFloat();
		System.out.println("Indique o tempo: ");
		float t= input.nextFloat();
		
		float pf = p0 + (v * t) + ((a * (t * t)) / 2);
		System.out.println("A posicao final do movel eh: "+ pf);
	
	}
}
