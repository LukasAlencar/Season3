/*Escreva um programa que leia um n�mero inteiro fornecido pelo usu�rio, armazenando-o numa vari�vel apropriada.
Imprima o valor lido. */


import java.util.Scanner;



public class Exercicio1 {
	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe um valor inteiro: ");
		int valor = input.nextInt();
		System.out.println("O valor inserido foi: "+ valor );	
	}
	
	
}
