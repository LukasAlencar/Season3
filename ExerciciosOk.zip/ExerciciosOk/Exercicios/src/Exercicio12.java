import java.util.Scanner;

/*Escreva um programa capaz de calcular o pre�o total a ser pago por uma compra de copos pl�sticos. O usu�rio deve
fornecer o n�mero de copos a serem comprados e o programa deve calcular o pre�o total a ser cobrado, exibindo-o.
Observe que: se o n�mero de copo � inferior ou igual a 100, o pre�o por copo � R$0.05; se o n�mero de copos est� entre
101 e 500, o pre�o por copo � R$0.04; finalmente se o n�mero de copos � superior a 500 o pre�o por copo � R$0.035. */


public class Exercicio12 {
	
	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe a quantidade de copos que ir� comprar: ");
		int qntd = input.nextInt();
		
		if(qntd <= 100) {
			System.out.println("O valor a ser pago �: RS" + (qntd * 0.05));
		}else if(qntd > 100 && qntd <= 500) {
			System.out.println("O valor a ser pago �: RS" + (qntd * 0.04));
		}else if(qntd > 500) {
			System.out.println("O valor a ser pago �: RS" + (qntd * 0.035));
		}
		
	}

}
