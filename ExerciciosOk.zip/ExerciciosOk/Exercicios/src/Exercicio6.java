/*Escreva um programa que leia dois valores, os quais denominaremos A e B, fornecidos pelo usu�rio, exibindo respostas
F ou V para as seguintes quest�es:
(a) A � maior que zero?
(b) B � maior que zero;
(c) A E B s�o maiores do que zero?
Use operadores l�gicos para formular as express�es necess�rias a avalia��o dos valores. */



import java.util.Scanner;

public class Exercicio6 {
	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe um valor (A): ");
		float valorA= input.nextFloat();
		System.out.println("Informe um valor (B): ");
		float valorB= input.nextFloat();
		
		System.out.println(""
				+ "(a) A � maior que zero? R="+((valorA > 0)? "V" : "F")+ "\r\n"
				+ "(b) B � maior que zero? R="+((valorB > 0)? "V" : "F")+"\r\n"
				+ "(c) A E B s�o maiores do que zero? R="+((valorA > 0) && (valorB > 0) ? "V" : "F"));
		
	}
}
