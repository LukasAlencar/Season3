import java.util.Scanner;

/*Escreva um programa que realize as seguintes tarefas:
a) Efetue a leitura de dois valores inteiros, os quais ser�o denominados x e y;
b) Realize a soma dos valores x e y, exibindo seu resultado;
c) Realize o produto dos valores x e y exibindo seu resultado;
d) Compare os valores x e y, indicando se "X > Y", "X = Y" e "X < Y" para os casos correspondentes. */


public class Exercicio15 {
	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe um valor (A): ");
		int x= input.nextInt();
		System.out.println("Informe um valor (B): ");
		int y= input.nextInt();
			
		int soma = x + y;
		int produto = x * y;
		
		System.out.println("A soma de x e y �: "+ soma);
		System.out.println("O produto de x e y �: "+ produto);
		
		if(x == y) {
			System.out.println("X = Y");
		}else if(x > y) {
			System.out.println("X > Y");
		}else {
			System.out.println("X < Y");
		}
	}
}
