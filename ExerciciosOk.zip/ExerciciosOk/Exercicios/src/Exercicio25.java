
import java.util.Scanner;

public class Exercicio25 {
	Scanner scan = new Scanner(System.in);
	public void run01(){

		
		int i = 0;
		System.out.println("Quantos numeros deseja somar? ");
		int qnt = scan.nextInt();
		double soma = 0;
		while(i < qnt){
			
			System.out.println("Digite o um numero: ");
			double num = scan.nextDouble();
			soma = soma + num;
			i++;
		}
		System.out.println("o resultado das somas �: "+ soma);
		
	}
	
}
