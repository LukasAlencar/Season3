import java.util.Scanner;

public class Exercicio30 {
	
	
	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe um valor (A): ");
		int a= input.nextInt();
		
		System.out.println("Informe um valor (B): ");
		int b= input.nextInt();
		
		System.out.println("Informe o valor do limite inferior de (X): ");
		int LIx= input.nextInt();
		
		System.out.println("Informe o valor do limite superior de (X): ");
		int LSx= input.nextInt();
		
		
		System.out.println("Informe o valor do incremento de (X): ");
		int Ix= input.nextInt();
		
		int resul = 0;
		
		
		int i = (int)LIx;
		
		while(i < LSx) {
			
			
			resul = (a * i) + b;
			
			System.out.println("Se x: |"+ i + "|, y �:" + " |" + resul + "| f(" + i + ")");
			i = i + Ix;
			
		}
		
		
	}
}