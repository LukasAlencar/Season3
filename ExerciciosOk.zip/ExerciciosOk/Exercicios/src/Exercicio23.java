import java.util.Scanner;
import java.lang.Math;

/*Escreva um programa que receba as seguintes informa��es: um valor real indicando capital inicial PV,
 * um valor real que corresponde a taxa de juros da aplica��o J e um n�mero inteiro de per�odos da aplica��o N.
 * O programa deve retornar o capital futuro FV dado pela rela��o abaixo: FV = PV * ( 1 + J )*/


public class Exercicio23 {
	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Indique o capital inicial: ");
		float pv= input.nextFloat();
		System.out.println("Indique a taxa de juros:  ");
		float j= input.nextFloat();
		System.out.println("Indique os periodos: ");
		int n= input.nextInt();
		
		
		float elev = (float)Math.pow((1 + j), (n));
		float fv = pv * elev;
		
		System.out.println(fv);
	}	
}
