
import java.util.Scanner;

public class MainEx {

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		
		
		System.out.println("Qual exercicio deseja rodar?");
		int opc = input.nextInt();
		switch(opc) {
		
			case 1:
				Exercicio1 ex1 = new Exercicio1(); 
				ex1.run01();
				break;
			case 2:
				Exercicio2 ex2 = new Exercicio2();
				ex2.run01();
				break;				
			case 3:
				Exercicio3 ex3 = new Exercicio3();
				ex3.run01();
				break;		
			case 4:
				Exercicio4 ex4 = new Exercicio4();
				ex4.run01();
				break;		
			case 5:
				Exercicio5 ex5 = new Exercicio5();
				ex5.run01();
				break;		
			case 6:
				Exercicio6 ex6 = new Exercicio6();
				ex6.run01();
				break;		
			case 7:
				Exercicio7 ex7 = new Exercicio7();
				ex7.run01();
				break;
			case 8:
				Exercicio8 ex8 = new Exercicio8();
				ex8.run01();
				break;
			case 9:
				Exercicio9 ex9 = new Exercicio9();
				ex9.run01();
				break;	
			case 10:
				Exercicio10 ex10 = new Exercicio10();
				ex10.run01();
				break;
			case 11:
				Exercicio11 ex11 = new Exercicio11();
				ex11.run01();
				break;	
			case 12:
				Exercicio12 ex12 = new Exercicio12();
				ex12.run01();
				break;	
			case 13:
				Exercicio13 ex13 = new Exercicio13();
				ex13.run01();
				break;
			case 14:
				Exercicio14 ex14 = new Exercicio14();
				ex14.run01();
				break;
			case 19:
				Exercicio19 ex19 = new Exercicio19();
				ex19.run01();
				break;
			case 21:
				Exercicio21 ex21 = new Exercicio21();
				ex21.run01();
				break;
			case 22:
				Exercicio22 ex22 = new Exercicio22();
				ex22.run01();
				break;
			case 23:
				Exercicio23 ex23 = new Exercicio23();
				ex23.run01();
				break;
			case 24:
				Exercicio24 ex24 = new Exercicio24();
				ex24.run01();
				break;
			case 25:
				Exercicio25 ex25 = new Exercicio25();
				ex25.run01();
				break;
			case 26:
				Exercicio26 ex26 = new Exercicio26();
				ex26.run01();
			case 27:
				Exercicio27 ex27 = new Exercicio27();
				ex27.run01();
			case 28:
				Exercicio28 ex28 = new Exercicio28();
				ex28.run01();
				break;
				
			 case 29: Exercicio29 ex29 = new Exercicio29();
			 ex29.run01();
			 break;
			 
			 case 30: Exercicio30 ex30 = new Exercicio30();
			 ex30.run01();
			 break;
				 
		}	
	}
		
		
}


