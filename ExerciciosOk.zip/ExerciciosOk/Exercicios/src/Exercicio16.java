import java.util.Scanner;

/*Preparar um programa para ler as medidas da base e da altura de um tri�ngulo, calculando e imprimindo sua �rea,
sabendo que o c�lculo da �rea � dado por:
area = (base*altura)/2.*/


public class Exercicio16 {
	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe a area da base do triangulo: ");
		float base= input.nextFloat();
		System.out.println("Informe a altura do triangulo: ");
		float altura= input.nextFloat();
		
		float area = (base * altura)/2;
		
		System.out.println("A area do triangulo �: "+ area);
	}
}
