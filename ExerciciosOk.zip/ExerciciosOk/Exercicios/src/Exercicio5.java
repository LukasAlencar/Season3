import java.util.Scanner;

/*Dado um n�mero inteiro qualquer, fornecido pelo usu�rio, descobrir se o mesmo � par ou �mpar. */

public class Exercicio5 {

	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe um valor: ");
		float valor = input.nextFloat();
		if(valor % 2 == 0) {
			System.out.println("o valor digitado foi par!");
		}else {
			System.out.println("o valor digitado foi impar!");
		}
		
	}
	
}
