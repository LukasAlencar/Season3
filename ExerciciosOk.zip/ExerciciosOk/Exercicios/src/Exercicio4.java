import java.util.Scanner;

/*Leia um n�mero qualquer fornecido pelo usu�rio. Determine se o n�mero � maior do que 100, imprimindo uma
mensagem indicando que o "valor � maior que 100" ou uma mensagem indicando que o "valor � menor ou igual a 100". 
*/

public class Exercicio4 {

	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe um valor: ");
		float valor = input.nextFloat();
		if(valor > 100) {
			System.out.println("O valor inserido foi maior que 100");	
		}else{
			System.out.println("O valor inserido foi menor ou igual a 100");
		}
	
	
	}
}
