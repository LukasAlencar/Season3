import java.util.Scanner;

/*Leia tr�s n�meros reais fornecidos pelo usu�rio. Descubra qual deles � o menor de todos, imprimindo seu valor*/

public class Exercicio9 {

	Scanner input = new Scanner(System.in);
	public void run01() {
		
		float valor[] = new float[3];
		
		System.out.println("Informe um valor (A): ");
		valor[0]= input.nextFloat();
		
		System.out.println("Informe um valor (B): ");
		valor[1]= input.nextFloat();
		
		System.out.println("Informe um valor (C): ");
		valor[2]= input.nextFloat();
		
		float aux = valor[1];
		
		for(int i = 0; i < valor.length; i++) {
			if(valor[i] < aux) {
				aux = valor[i]; 
			}
		}
		
		System.out.println("O menor valor digitado foi: "+ aux);
		
	}
	
}
