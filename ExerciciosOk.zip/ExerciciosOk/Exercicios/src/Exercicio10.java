import java.util.Arrays;
import java.util.Scanner;

/*Leia tr�s n�meros quaisquer, imprimindo-os em ordem crescente*/

public class Exercicio10 {

	Scanner input = new Scanner(System.in);
	public void run01() {
		
		float valor[] = new float[3];
		
		System.out.println("Informe um valor (A): ");
		valor[0]= input.nextFloat();
		
		System.out.println("Informe um valor (B): ");
		valor[1]= input.nextFloat();
		
		System.out.println("Informe um valor (C): ");
		valor[2]= input.nextFloat();
		
		float aux = valor[1];
		
		for(int i = 0; i < valor.length; i++) {
			if(valor[i] < aux) {
				aux = valor[i]; 
			}
		}
		
		Arrays.sort(valor);
		
		System.out.println("\nA ordem crescente �: \n");
		for(int cont = 0; cont < valor.length; cont++) {
			System.out.println(valor[cont]+"\n");
			
			
		}
		
	}
	
	
}
