import java.util.Scanner;

/*Escreva um programa que leia um valor real correspondente a uma medida em metros, convertendo o valor dado em p�s
(1 metro = 3.315 p�s), exibindo os valores dado e convertido. Caso o usu�rio forne�a um valor negativo, deve ser exibida
uma mensagem e a opera��o de convers�o n�o deve ser efetuada. */


public class Exercicio20 {
	
		Scanner input = new Scanner(System.in);
		public void run01() {
			System.out.println("Informe um valor em metros: ");
			float metros= input.nextFloat();
			
			if(metros > 0) {
				float pes = metros * 3315;
				System.out.println( metros + "metros � igual a: "+ pes + " pes");
			}else {
				System.out.println("N�o sera possivel completar a operacao");
			}
		}
}
