/*Leia um n�mero qualquer fornecido pelo usu�rio. Determine se o n�mero � maior do que 50, imprimindo uma mensagem
indicando tal fato.*/

import java.util.Scanner;

public class Exercicio3 {
	
	Scanner input = new Scanner(System.in);
	public void run01() {
		System.out.println("Informe um valor: ");
		float valor = input.nextFloat();
		if(valor > 50)
			System.out.println("O valor inserido foi maior que 50");	
	
	
	}
	
}
