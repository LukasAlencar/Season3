
import java.util.Scanner;

public class Exercicio26 {
	Scanner scan = new Scanner(System.in);
	public void run01(){

		
		int i = 0;
		double soma = 0;
		double num = 1;
		do{
			
			System.out.println("Digite o um numero: ");
			num = scan.nextDouble();
			soma = soma + num;
			i++;
		}while(num != 0);
		System.out.println("o resultado das somas �: "+ soma);
		
	}
	
}
