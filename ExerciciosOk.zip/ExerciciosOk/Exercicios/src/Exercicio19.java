import java.util.Scanner;
import java.lang.Math;
import java.math.BigDecimal;
import java.math.RoundingMode;


public class Exercicio19 {
	
	Scanner input = new Scanner(System.in);
	public void run01(){
        
		
		int u,d;
        System.out.println("Digite um valor real: ");
        float num = input.nextFloat();
        int c, c_dz, c_un;
        float cent;
        
        String extenso = "", conexao, classeMonetaria, conexaoCent, classeMonetariaCent, extensoCent;
        String[] unidade,dezena,dezenaespecial;
        String valorString;
        
        unidade        = new String[10];
        dezena         = new String[10];
        dezenaespecial = new String[10];
         
        unidade[0] = "";
        unidade[1] = "um";
        unidade[2] = "dois";
        unidade[3] = "tr�s";
        unidade[4] = "quatro";
        unidade[5] = "cinco";
        unidade[6] = "seis";
        unidade[7] = "sete";
        unidade[8] = "oito";
        unidade[9] = "nove";
        
        dezena[0] = "";
        dezena[1] = "dez";
        dezena[2] = "vinte";
        dezena[3] = "trinta";
        dezena[4] = "quarenta";
        dezena[5] = "cinquenta";
        dezena[6] = "sessenta";
        dezena[7] = "setenta";
        dezena[8] = "oitenta";
        dezena[9] = "noventa";
         
        dezenaespecial[0] = "dez";
        dezenaespecial[1] = "onze";
        dezenaespecial[2] = "doze";
        dezenaespecial[3] = "treze";
        dezenaespecial[4] = "quatorze";
        dezenaespecial[5] = "quinze";
        dezenaespecial[6] = "dezesseis";
        dezenaespecial[7] = "dezessete";
        dezenaespecial[8] = "dezoito";
        dezenaespecial[9] = "dezenove";
         
        if (num >= 1 && num <= 99){
        	d = (int)(num / 10);
            u = (int)(num % 10);
             
            c = (int)(num);
            cent = num - (float)c; 
            BigDecimal bd = new BigDecimal(cent).setScale(2, RoundingMode.HALF_EVEN);
          
            cent = bd.floatValue() * 100;
             
           	
           	c_dz = (int)(cent / 10);
           	c_un = (int)(cent % 10);
             	
            
           	if(c_dz < 0 && c_un <0) {
           		
           	}
           	conexaoCent = "";
           	if (c_dz > 0 && c_un > 0){
                 conexaoCent = " e ";
            }
             
            if (cent > 10 && cent < 20){
           	  	classeMonetariaCent = " centavos"; 	
                 extensoCent = dezenaespecial[c_un] + classeMonetariaCent;
            }
            else{
                classeMonetariaCent = " centavos"; 
           	 extensoCent = dezena[c_dz] + conexaoCent + unidade[c_un] + classeMonetariaCent;
            }
            
            conexao = "";
            
            if(cent == 0) {
            	extensoCent ="";
            	conexaoCent = " ";
            }
            if (d > 0 && u > 0){
            	conexao = " e ";
            }
              
            if (num >= 10 && num < 20){	 
            	classeMonetaria = " reais";
            	conexao = " e ";
                extenso = dezenaespecial[u] + classeMonetaria + conexaoCent + extensoCent;
            }
            else{
            	classeMonetaria = " reais"; 
           	    extenso = dezena[d] + conexao + unidade[u] + classeMonetaria + conexaoCent + extensoCent;
            }
        }else if(num == 100){
        	System.out.println("cem reais");
        	
        }
        System.out.println(extenso); 
       }
           	
           	
           	
           	
          	
   
}

