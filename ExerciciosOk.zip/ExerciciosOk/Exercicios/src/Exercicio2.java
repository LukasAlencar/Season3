/*Escreva um programa que leia um n�mero real fornecido pelo usu�rio, armazenando-o numa vari�vel apropriada.
Imprima o valor lido. */

import java.util.Scanner;

public class Exercicio2 {
	
		Scanner input = new Scanner(System.in);
		public void run01() {
			System.out.println("Informe um valor real: ");
			float valor = input.nextFloat();
			System.out.println("O valor inserido foi: "+ valor );	
		}
	}

