
public class Exercicio29 {
	
	boolean a = false;
	boolean b = true;
	boolean c = false;
	
	
	public void run01() {
		
		System.out.println("|A| |B| |C|\n"
	    		 + "|V| |V| |V| = |V|\n"
	    		 + "|V| |F| |F| = |V|\n"
	    		 + "|V| |V| |F| = |V|\n"
	    		 + "|V| |F| |V| = |V|\n"
	    		 + "|F| |V| |V| = |V|\n"
	    		 + "|F| |F| |V| = |V|\n"
	    		 + "|F| |F| |F| = |F|\n");	
		
		verificarVF(a, b, c);
	}
	
	
	public void verificarVF(boolean a, boolean b, boolean c) {
		
		if(a == true || b == true || c == true) {
			System.out.println("\nVariavel A declarada como: " + a + "\nVariavel B declarada como: " + b 
					+ "\nVariavel C declarada como: " + c + "\nentao a declaracao eh: Verdadeira");
			
		}else {
			System.out.println("\nVariavel A declarada como: " + a + "\nVariavel B declarada como: " + b 
					+ "\nVariavel C declarada como: " + c + "\nentao a declaracao eh: Falsa");
		}
	}
}
