import java.util.Scanner;

/*Escreva um programa que leia 3 notas (valores reais), calculando e exibindo sua m�dia aritm�tica. Imprima tamb�m
"Aprovado" se a m�dia for maior que 7, "Reprovado" se for menor que 3 e "Exame" se estiver entre 3 e 7. */

public class Exercicio14 {

Scanner input = new Scanner(System.in);
	
	
	public void run01() {
	
		
		System.out.println("Informe as notas:");
		
		System.out.println("\nInforme a nota (A): ");
		float a = input.nextFloat();
	
		System.out.println("\nInforme a nota (B): ");
		float b = input.nextFloat();
	
		System.out.println("\nInforme a nota (C): ");
		float c = input.nextFloat();
		
		float media = a + b + c;
		
		if(media > 7) {
			System.out.println("\nAprovado");
		}else if(media < 3) {
			System.out.println("\nReprovado");
		}else {
			System.out.println("Exame");
		}
		
	
	}
	
	
}
