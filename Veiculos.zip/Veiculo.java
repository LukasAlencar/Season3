public class Veiculo {

	private String veiculo;
	private int ano;
	private int valor;
	private String tipo;
	
	
	public Veiculo() {
		
	}
	
	public Veiculo(String veiculo, int ano, int valor, String tipo) {
		this.setVeiculo(veiculo);
		this.setAno(ano);
		this.setValor(valor);
		this.setTipo(tipo);
	}
	
	
	
	@Override
	public String toString() {
		return (
				 this.getVeiculo() + ", "+
				 this.getAno() 	   + ", "+
				 this.getValor()   + ", "+
				 this.getTipo()   
				);
	}
	
	
	
	
	
	public String getVeiculo() {
		return this. veiculo;
	}



	public void setVeiculo(String veiculo) {
		this.veiculo = veiculo;
	}

	public void setAno(int ano) {
		this.ano = ano;
	}
	
	public void setValor(int valor) {
		this.valor = valor;
	}
	
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}


	public int getAno() {
		return this.ano;
	}


	public int getValor() {
		return this.valor;
	}

	public String getTipo() {
		return this.tipo;
	}
	





	
	

}
